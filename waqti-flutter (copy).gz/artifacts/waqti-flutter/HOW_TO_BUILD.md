# بناء تطبيق وقتي — APK

## المتطلبات

1. **Flutter SDK** (نسخة 3.13 أو أحدث)
   - تحميل: https://flutter.dev/docs/get-started/install
   
2. **Android Studio** أو **Android SDK**
   - يجب تثبيت: `Build Tools 34`, `Platform 34`
   
3. **Java JDK 11** أو أحدث

---

## الخطوات

### 1. إعداد البيئة

```bash
# تأكد أن Flutter مثبت بشكل صحيح
flutter doctor

# يجب أن يظهر ✓ بجانب Flutter و Android toolchain
```

### 2. نسخ ملف local.properties

```bash
cp android/local.properties.template android/local.properties
# ثم عدّل المسارات في الملف:
# flutter.sdk = مسار Flutter SDK على جهازك
# sdk.dir = مسار Android SDK على جهازك
```

### 3. تثبيت الحزم

```bash
flutter pub get
```

### 4. بناء APK

```bash
# تنظيف أولاً
flutter clean

# تثبيت الحزم
flutter pub get

# بناء APK مقسم حسب المعمارية (الأصغر حجماً)
flutter build apk --release --split-per-abi
```

### 5. موقع الـ APK

بعد اكتمال البناء، الـ APK يكون في:
```
build/app/outputs/flutter-apk/app-arm64-v8a-release.apk   (للهواتف الحديثة 64-bit)
build/app/outputs/flutter-apk/app-armeabi-v7a-release.apk  (للهواتف القديمة 32-bit)
```

---

## الأذونات المطلوبة بعد التثبيت

عند أول تشغيل، يجب منح هذه الأذونات يدوياً:

1. **إحصائيات الاستخدام** (Usage Stats) — من الإعدادات > الخصوصية
2. **الظهور فوق التطبيقات** (Draw Over Apps) — من الإعدادات > التطبيقات
3. **خدمة إمكانية الوصول** (Accessibility) — من الإعدادات > إمكانية الوصول

---

## ملاحظة حول الخطوط

ضع ملفات خط Tajawal في:
```
assets/fonts/Tajawal-Regular.ttf
assets/fonts/Tajawal-Medium.ttf
assets/fonts/Tajawal-Bold.ttf
assets/fonts/Tajawal-ExtraBold.ttf
assets/fonts/Tajawal-Black.ttf
```

تحميل خط Tajawal: https://fonts.google.com/specimen/Tajawal
