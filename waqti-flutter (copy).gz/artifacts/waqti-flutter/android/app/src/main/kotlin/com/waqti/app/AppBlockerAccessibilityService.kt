package com.waqti.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppBlockerAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == applicationContext.packageName) return
        if (packageName.startsWith("com.android.")) return

        checkAndBlock(packageName)
    }

    private fun checkAndBlock(packageName: String) {
        val prefs = getSharedPreferences("waqti_prefs", MODE_PRIVATE)
        val exceeded = prefs.getStringSet("limit_exceeded", emptySet()) ?: return

        if (packageName in exceeded) {
            val intent = Intent("com.waqti.TIME_EXCEEDED")
            intent.putExtra("package", packageName)
            sendBroadcast(intent)
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    override fun onInterrupt() {}
}
