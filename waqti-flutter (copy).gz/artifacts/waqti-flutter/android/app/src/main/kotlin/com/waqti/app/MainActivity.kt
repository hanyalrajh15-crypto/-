package com.waqti.app

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.Calendar

class MainActivity : FlutterActivity() {

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.waqti.app/usage")
            .setMethodCallHandler { call, result ->
                when (call.method) {

                    "getTodayUsage" -> {
                        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
                        val cal = Calendar.getInstance().apply {
                            set(Calendar.HOUR_OF_DAY, 0)
                            set(Calendar.MINUTE, 0)
                            set(Calendar.SECOND, 0)
                        }
                        val stats = usm.queryUsageStats(
                            UsageStatsManager.INTERVAL_DAILY,
                            cal.timeInMillis, System.currentTimeMillis()
                        )
                        val map = mutableMapOf<String, Long>()
                        stats?.forEach {
                            if (it.totalTimeInForeground > 0)
                                map[it.packageName] = it.totalTimeInForeground
                        }
                        result.success(map)
                    }

                    "getInstalledApps" -> {
                        val apps = packageManager
                            .getInstalledApplications(PackageManager.GET_META_DATA)
                            .filter { packageManager.getLaunchIntentForPackage(it.packageName) != null }
                            .map {
                                mapOf(
                                    "packageName" to it.packageName,
                                    "name" to packageManager.getApplicationLabel(it).toString()
                                )
                            }
                        result.success(apps)
                    }

                    "hasUsageStatsPermission" -> {
                        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
                        val mode = ops.checkOpNoThrow(
                            AppOpsManager.OPSTR_GET_USAGE_STATS,
                            android.os.Process.myUid(),
                            packageName
                        )
                        result.success(mode == AppOpsManager.MODE_ALLOWED)
                    }

                    "openUsageStatsSettings" -> {
                        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                        result.success(null)
                    }

                    "hasOverlayPermission" -> {
                        result.success(Settings.canDrawOverlays(this))
                    }

                    "openOverlaySettings" -> {
                        startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                        )
                        result.success(null)
                    }

                    "hasAccessibilityPermission" -> {
                        val enabled = Settings.Secure.getString(
                            contentResolver,
                            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                        )
                        result.success(enabled?.contains(packageName) == true)
                    }

                    "openAccessibilitySettings" -> {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        result.success(null)
                    }

                    "startMonitorService" -> {
                        startForegroundService(Intent(this, MonitorService::class.java))
                        result.success(null)
                    }

                    else -> result.notImplemented()
                }
            }
    }
}
