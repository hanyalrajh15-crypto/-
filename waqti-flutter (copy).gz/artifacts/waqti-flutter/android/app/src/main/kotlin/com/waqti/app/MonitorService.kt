package com.waqti.app

import android.app.*
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.util.Calendar

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val CHECK_INTERVAL = 60_000L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1, buildForegroundNotification())
        startMonitoring()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            "waqti_monitor", "وقتي — المراقبة",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val alertChannel = NotificationChannel(
            "waqti_alert", "وقتي — التنبيهات",
            NotificationManager.IMPORTANCE_HIGH
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(alertChannel)
    }

    private fun buildForegroundNotification(): Notification {
        return Notification.Builder(this, "waqti_monitor")
            .setContentTitle("وقتي")
            .setContentText("المراقبة نشطة")
            .setSmallIcon(android.R.drawable.ic_menu_clock)
            .build()
    }

    private fun startMonitoring() {
        handler.post(object : Runnable {
            override fun run() {
                checkAllLimits()
                handler.postDelayed(this, CHECK_INTERVAL)
            }
        })
    }

    private fun checkAllLimits() {
        val prefs = getSharedPreferences("waqti_prefs", MODE_PRIVATE)
        val monitored = prefs.getStringSet("monitored_apps", emptySet()) ?: return

        monitored.forEach { pkg ->
            val limitMin = prefs.getInt("limit_$pkg", 0)
            if (limitMin <= 0) return@forEach

            val usageMs = getUsageToday(pkg)
            val limitMs = limitMin * 60_000L
            val warningMin = prefs.getInt("warning_min", 10)
            val warningMs = warningMin * 60_000L

            when {
                usageMs >= limitMs -> {
                    markExceeded(pkg)
                    sendExceededNotification(pkg)
                }
                usageMs >= limitMs - warningMs -> {
                    val left = ((limitMs - usageMs) / 60_000).toInt()
                    sendWarningNotification(pkg, left)
                }
            }
        }
    }

    private fun getUsageToday(pkg: String): Long {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
        }
        return usm.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            cal.timeInMillis, System.currentTimeMillis()
        )?.find { it.packageName == pkg }?.totalTimeInForeground ?: 0L
    }

    private fun markExceeded(pkg: String) {
        val prefs = getSharedPreferences("waqti_prefs", MODE_PRIVATE)
        val set = prefs.getStringSet("limit_exceeded", mutableSetOf())!!.toMutableSet()
        set.add(pkg)
        prefs.edit().putStringSet("limit_exceeded", set).apply()
    }

    private fun sendWarningNotification(pkg: String, minutesLeft: Int) {
        val appName = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(pkg, 0)
            ).toString()
        } catch (e: Exception) { pkg }

        val n = Notification.Builder(this, "waqti_alert")
            .setContentTitle("⚠️ $appName")
            .setContentText("تبقى $minutesLeft دقيقة من وقتك")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .build()

        getSystemService(NotificationManager::class.java).notify(pkg.hashCode(), n)
    }

    private fun sendExceededNotification(pkg: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            action = "SHOW_EMERGENCY"
            putExtra("package", pkg)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "waqti_alert")
            .setContentTitle("⏰ انتهى وقتك!")
            .setContentText("اضغط للاختيار: طوارئ أو خروج")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setFullScreenIntent(pi, true)
            .build()

        getSystemService(NotificationManager::class.java).notify(pkg.hashCode() + 9000, n)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
