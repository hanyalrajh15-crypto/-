class AppModel {
  final String packageName;
  final String name;
  int usedMinutes;
  int limitMinutes;
  bool isMonitored;

  AppModel({
    required this.packageName,
    required this.name,
    this.usedMinutes = 0,
    this.limitMinutes = 0,
    this.isMonitored = false,
  });
}

class DayData {
  final String date;
  final int usedMinutes;
  final int limitMinutes;

  DayData({
    required this.date,
    required this.usedMinutes,
    required this.limitMinutes,
  });

  String get status {
    if (usedMinutes == 0) return 'none';
    if (limitMinutes == 0) return 'none';
    final ratio = usedMinutes / limitMinutes;
    if (ratio <= 0.6) return 'good';
    if (ratio <= 0.85) return 'warn';
    return 'bad';
  }
}
