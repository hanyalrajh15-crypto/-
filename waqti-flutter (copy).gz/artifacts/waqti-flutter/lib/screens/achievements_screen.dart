import 'package:flutter/material.dart';

const _kOrange = Color(0xFFFF6B1A);

class AchievementsScreen extends StatelessWidget {
  final int totalMinutesToday;
  final int dailyLimit;

  const AchievementsScreen({
    super.key,
    required this.totalMinutesToday,
    required this.dailyLimit,
  });

  static const _achievements = [
    {
      'icon': '🔥',
      'title': 'سلسلة 7 أيام',
      'desc': 'حافظت على حدك اليومي لأسبوع كامل',
      'target': 7,
      'current': 3,
    },
    {
      'icon': '⚡',
      'title': 'يوم بدون تجاوز',
      'desc': 'لم تتجاوز حدك اليومي اليوم',
      'target': 1,
      'current': 1,
    },
    {
      'icon': '🌟',
      'title': 'شهر منضبط',
      'desc': 'حافظت على حدك لمدة 30 يوم',
      'target': 30,
      'current': 3,
    },
    {
      'icon': '🧘',
      'title': 'ساعة هدوء',
      'desc': 'مرت ساعة بدون استخدام الهاتف',
      'target': 1,
      'current': 0,
    },
    {
      'icon': '🎯',
      'title': 'ضبط الحدود',
      'desc': 'حددت حدوداً لـ 5 تطبيقات',
      'target': 5,
      'current': 2,
    },
  ];

  @override
  Widget build(BuildContext context) {
    final streakDays = 3;
    final pct = dailyLimit > 0
        ? (totalMinutesToday / dailyLimit).clamp(0.0, 1.0)
        : 0.0;

    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                  child: Row(
                    children: const [
                      Text(
                        'الإنجازات',
                        style: TextStyle(
                          fontFamily: 'Tajawal',
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                _buildStreakCard(streakDays, pct),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    'التحديات',
                    style: TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: Colors.white.withOpacity(0.6),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                ..._achievements.map((a) => _AchievementCard(data: a)),
                const SizedBox(height: 80),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStreakCard(int days, double todayPct) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            _kOrange.withOpacity(0.25),
            const Color(0xFF0A0A0A),
          ],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _kOrange.withOpacity(0.3), width: 1.5),
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '🔥',
                style: TextStyle(fontSize: 40),
              ),
              const SizedBox(height: 8),
              Text(
                '$days أيام',
                style: const TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                  color: _kOrange,
                ),
              ),
              Text(
                'سلسلة متواصلة',
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 14,
                  color: Colors.white.withOpacity(0.55),
                ),
              ),
            ],
          ),
          const Spacer(),
          Column(
            children: [
              SizedBox(
                width: 80,
                height: 80,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CircularProgressIndicator(
                      value: todayPct,
                      backgroundColor: Colors.white.withOpacity(0.1),
                      valueColor:
                          const AlwaysStoppedAnimation<Color>(_kOrange),
                      strokeWidth: 8,
                    ),
                    Text(
                      '${(todayPct * 100).round()}%',
                      style: const TextStyle(
                        fontFamily: 'Tajawal',
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'اليوم',
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 12,
                  color: Colors.white.withOpacity(0.4),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AchievementCard extends StatelessWidget {
  final Map data;

  const _AchievementCard({required this.data});

  @override
  Widget build(BuildContext context) {
    final current = data['current'] as int;
    final target = data['target'] as int;
    final done = current >= target;
    final pct = (current / target).clamp(0.0, 1.0);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: done
            ? _kOrange.withOpacity(0.1)
            : const Color(0xFF141414),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: done ? _kOrange.withOpacity(0.4) : Colors.white.withOpacity(0.06),
        ),
      ),
      child: Row(
        children: [
          Text(data['icon'] as String, style: const TextStyle(fontSize: 32)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      data['title'] as String,
                      style: const TextStyle(
                        fontFamily: 'Tajawal',
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    if (done)
                      const Padding(
                        padding: EdgeInsets.only(right: 8),
                        child: Icon(Icons.check_circle,
                            color: _kOrange, size: 16),
                      ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  data['desc'] as String,
                  style: TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 11,
                    color: Colors.white.withOpacity(0.4),
                  ),
                ),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: pct,
                  backgroundColor: Colors.white.withOpacity(0.08),
                  valueColor:
                      const AlwaysStoppedAnimation<Color>(_kOrange),
                  minHeight: 4,
                ),
                const SizedBox(height: 4),
                Text(
                  '$current / $target',
                  style: TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 10,
                    color: Colors.white.withOpacity(0.3),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
