import 'package:flutter/material.dart';
import '../models/app_model.dart';
import '../services/storage_service.dart';

const _kOrange = Color(0xFFFF6B1A);

class AppsScreen extends StatefulWidget {
  final List<AppModel> apps;
  final VoidCallback onRefresh;

  const AppsScreen({super.key, required this.apps, required this.onRefresh});

  @override
  State<AppsScreen> createState() => _AppsScreenState();
}

class _AppsScreenState extends State<AppsScreen> {
  String _search = '';

  List<AppModel> get _filtered => widget.apps
      .where((a) =>
          a.name.contains(_search) || a.packageName.contains(_search))
      .toList();

  String _formatMinutes(int min) {
    final h = min ~/ 60;
    final m = min % 60;
    if (h == 0) return '${m}د';
    return '${h}س ${m}د';
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
            child: Row(
              children: [
                const Text(
                  'التطبيقات',
                  style: TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: widget.onRefresh,
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.refresh_rounded,
                        color: Colors.white54, size: 18),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
              ),
              child: TextField(
                onChanged: (v) => setState(() => _search = v),
                style: const TextStyle(
                    fontFamily: 'Tajawal', color: Colors.white, fontSize: 14),
                decoration: InputDecoration(
                  hintText: 'ابحث عن تطبيق...',
                  hintStyle: TextStyle(
                      fontFamily: 'Tajawal',
                      color: Colors.white.withOpacity(0.3),
                      fontSize: 14),
                  prefixIcon:
                      Icon(Icons.search, color: Colors.white.withOpacity(0.3)),
                  border: InputBorder.none,
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              itemCount: _filtered.length,
              itemBuilder: (_, i) => _AppCard(
                app: _filtered[i],
                formatMinutes: _formatMinutes,
                onLimitChanged: (minutes) async {
                  await StorageService.setAppLimit(
                      _filtered[i].packageName, minutes);
                  setState(() {});
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AppCard extends StatelessWidget {
  final AppModel app;
  final String Function(int) formatMinutes;
  final Future<void> Function(int) onLimitChanged;

  const _AppCard({
    required this.app,
    required this.formatMinutes,
    required this.onLimitChanged,
  });

  void _showLimitDialog(BuildContext context) {
    int tempLimit = app.limitMinutes;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: Text(
          'حد ${app.name}',
          style: const TextStyle(fontFamily: 'Tajawal', color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            StatefulBuilder(
              builder: (_, setState) => Column(
                children: [
                  Text(
                    '${tempLimit} دقيقة',
                    style: const TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 28,
                      fontWeight: FontWeight.w800,
                      color: _kOrange,
                    ),
                  ),
                  Slider(
                    value: tempLimit.toDouble(),
                    min: 0,
                    max: 480,
                    divisions: 48,
                    activeColor: _kOrange,
                    onChanged: (v) => setState(() => tempLimit = v.round()),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء',
                style: TextStyle(fontFamily: 'Tajawal', color: Colors.white54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _kOrange),
            onPressed: () {
              onLimitChanged(tempLimit);
              Navigator.pop(context);
            },
            child: const Text('حفظ',
                style: TextStyle(fontFamily: 'Tajawal', color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pct = app.limitMinutes > 0
        ? (app.usedMinutes / app.limitMinutes).clamp(0.0, 1.0)
        : 0.0;
    final color = pct >= 1.0
        ? const Color(0xFFE53935)
        : pct >= 0.8
            ? const Color(0xFFFFB300)
            : const Color(0xFF4CAF50);

    return GestureDetector(
      onTap: () => _showLimitDialog(context),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF141414),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.06)),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  app.name.isNotEmpty ? app.name[0] : '?',
                  style: const TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    app.name,
                    style: const TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  LinearProgressIndicator(
                    value: pct,
                    backgroundColor: Colors.white.withOpacity(0.08),
                    valueColor: AlwaysStoppedAnimation<Color>(
                        app.usedMinutes > 0 ? color : Colors.white24),
                    minHeight: 4,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  formatMinutes(app.usedMinutes),
                  style: TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: app.usedMinutes > 0 ? color : Colors.white38,
                  ),
                ),
                if (app.limitMinutes > 0)
                  Text(
                    '/ ${formatMinutes(app.limitMinutes)}',
                    style: TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 10,
                      color: Colors.white.withOpacity(0.3),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
