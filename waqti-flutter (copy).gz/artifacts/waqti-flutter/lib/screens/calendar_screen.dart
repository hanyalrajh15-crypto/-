import 'package:flutter/material.dart';
import '../models/app_model.dart';
import '../services/storage_service.dart';
import 'package:intl/intl.dart';

const _kOrange = Color(0xFFFF6B1A);
const _kGreen = Color(0xFF4CAF50);
const _kYellow = Color(0xFFFFB300);
const _kRed = Color(0xFFE53935);

class CalendarScreen extends StatefulWidget {
  final List<DayData> weekData;

  const CalendarScreen({super.key, required this.weekData});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _focusedMonth = DateTime.now();

  Color _dayColor(int day, int month, int year) {
    final dateStr =
        '$year-${month.toString().padLeft(2, '0')}-${day.toString().padLeft(2, '0')}';
    final wd = widget.weekData.where((d) => d.date == dateStr).firstOrNull;
    if (wd == null) return Colors.transparent;
    if (wd.status == 'good') return _kGreen;
    if (wd.status == 'warn') return _kYellow;
    if (wd.status == 'bad') return _kRed;
    return Colors.transparent;
  }

  List<int?> _getDaysInMonth(int year, int month) {
    final firstDay = DateTime(year, month, 1).weekday % 7;
    final daysInMonth = DateTime(year, month + 1, 0).day;
    final List<int?> days = List.filled(firstDay, null);
    for (int i = 1; i <= daysInMonth; i++) {
      days.add(i);
    }
    return days;
  }

  @override
  Widget build(BuildContext context) {
    final year = _focusedMonth.year;
    final month = _focusedMonth.month;
    final days = _getDaysInMonth(year, month);
    final now = DateTime.now();
    final monthName =
        DateFormat('MMMM yyyy', 'ar').format(_focusedMonth);

    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'التقويم',
                        style: TextStyle(
                          fontFamily: 'Tajawal',
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                        ),
                      ),
                      Row(
                        children: [
                          _NavBtn(
                            icon: Icons.chevron_right,
                            onTap: () => setState(() => _focusedMonth =
                                DateTime(year, month - 1, 1)),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            monthName,
                            style: const TextStyle(
                              fontFamily: 'Tajawal',
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(width: 12),
                          _NavBtn(
                            icon: Icons.chevron_left,
                            onTap: () => setState(() => _focusedMonth =
                                DateTime(year, month + 1, 1)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س']
                        .map((d) => SizedBox(
                              width: 36,
                              child: Text(
                                d,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Tajawal',
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white.withOpacity(0.35),
                                ),
                              ),
                            ))
                        .toList(),
                  ),
                ),
                const SizedBox(height: 8),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 7,
                    childAspectRatio: 1,
                    mainAxisSpacing: 6,
                    crossAxisSpacing: 6,
                  ),
                  itemCount: days.length,
                  itemBuilder: (_, i) {
                    final day = days[i];
                    if (day == null) return const SizedBox();
                    final isToday = day == now.day &&
                        month == now.month &&
                        year == now.year;
                    final dayColor = _dayColor(day, month, year);
                    final isFuture = DateTime(year, month, day).isAfter(now);

                    return Container(
                      decoration: BoxDecoration(
                        color: isToday
                            ? _kOrange.withOpacity(0.25)
                            : dayColor != Colors.transparent
                                ? dayColor.withOpacity(0.2)
                                : Colors.white.withOpacity(0.04),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: isToday
                              ? _kOrange
                              : dayColor != Colors.transparent
                                  ? dayColor.withOpacity(0.5)
                                  : Colors.transparent,
                          width: 1.5,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '$day',
                            style: TextStyle(
                              fontFamily: 'Tajawal',
                              fontSize: 13,
                              fontWeight:
                                  isToday ? FontWeight.w900 : FontWeight.w500,
                              color: isFuture
                                  ? Colors.white.withOpacity(0.2)
                                  : isToday
                                      ? _kOrange
                                      : Colors.white,
                            ),
                          ),
                          if (dayColor != Colors.transparent && !isFuture)
                            Container(
                              width: 5,
                              height: 5,
                              decoration: BoxDecoration(
                                color: dayColor,
                                shape: BoxShape.circle,
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                ),
                const SizedBox(height: 20),
                _buildLegend(),
                const SizedBox(height: 80),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegend() {
    final items = [
      ('ممتاز', _kGreen),
      ('تحذير', _kYellow),
      ('تجاوز', _kRed),
    ];
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: items
          .map((item) => Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                          color: item.$2, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      item.$1,
                      style: TextStyle(
                        fontFamily: 'Tajawal',
                        fontSize: 12,
                        color: Colors.white.withOpacity(0.5),
                      ),
                    ),
                  ],
                ),
              ))
          .toList(),
    );
  }
}

class _NavBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _NavBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: Colors.white54, size: 18),
      ),
    );
  }
}
