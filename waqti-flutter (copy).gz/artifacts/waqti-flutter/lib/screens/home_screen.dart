import 'package:flutter/material.dart';
import '../models/app_model.dart';
import '../services/usage_service.dart';
import '../services/storage_service.dart';
import '../widgets/week_chart.dart';
import 'apps_screen.dart';
import 'calendar_screen.dart';
import 'achievements_screen.dart';
import 'settings_screen.dart';

const _kOrange = Color(0xFFFF6B1A);

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  final _tabs = ['الرئيسية', 'التطبيقات', 'التقويم', 'الإنجازات'];
  final _tabIcons = [
    Icons.home_rounded,
    Icons.apps_rounded,
    Icons.calendar_month_rounded,
    Icons.emoji_events_rounded,
  ];

  Map<String, int> _usage = {};
  List<AppModel> _apps = [];
  bool _loadingUsage = true;

  List<DayData> get _weekData {
    final now = DateTime.now();
    return List.generate(7, (i) {
      final d = now.subtract(Duration(days: 6 - i));
      final dateStr = '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
      return DayData(
        date: dateStr,
        usedMinutes: i == 6 ? _totalUsedToday : (i * 23 + 40),
        limitMinutes: StorageService.getDailyLimit(),
      );
    });
  }

  int get _totalUsedToday {
    int total = 0;
    for (final v in _usage.values) {
      total += (v / 60000).round();
    }
    return total;
  }

  @override
  void initState() {
    super.initState();
    _loadUsage();
  }

  Future<void> _loadUsage() async {
    try {
      final usage = await UsageService.getTodayUsage();
      final installedRaw = await UsageService.getInstalledApps();
      setState(() {
        _usage = usage;
        _apps = installedRaw
            .map((a) => AppModel(
                  packageName: a['packageName'] as String,
                  name: a['name'] as String,
                  usedMinutes:
                      ((usage[a['packageName']] ?? 0) / 60000).round(),
                  limitMinutes:
                      StorageService.getAppLimit(a['packageName'] as String),
                ))
            .toList()
          ..sort((a, b) => b.usedMinutes.compareTo(a.usedMinutes));
        _loadingUsage = false;
      });
    } catch (_) {
      setState(() => _loadingUsage = false);
    }
  }

  String _formatMinutes(int min) {
    final h = min ~/ 60;
    final m = min % 60;
    if (h == 0) return '${m}د';
    return '${h}س ${m}د';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: _buildBody(),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF111111),
        border: Border(top: BorderSide(color: Colors.white.withOpacity(0.06))),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(_tabs.length, (i) {
              final active = _tab == i;
              return GestureDetector(
                onTap: () => setState(() => _tab = i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: active ? _kOrange.withOpacity(0.15) : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        _tabIcons[i],
                        color: active ? _kOrange : Colors.white.withOpacity(0.3),
                        size: 22,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _tabs[i],
                        style: TextStyle(
                          fontFamily: 'Tajawal',
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: active ? _kOrange : Colors.white.withOpacity(0.3),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    switch (_tab) {
      case 1:
        return AppsScreen(apps: _apps, onRefresh: _loadUsage);
      case 2:
        return CalendarScreen(weekData: _weekData);
      case 3:
        return AchievementsScreen(
          totalMinutesToday: _totalUsedToday,
          dailyLimit: StorageService.getDailyLimit(),
        );
      default:
        return _buildHome();
    }
  }

  Widget _buildHome() {
    final limit = StorageService.getDailyLimit();
    final used = _totalUsedToday;
    final pct = limit > 0 ? (used / limit).clamp(0.0, 1.0) : 0.0;
    final remaining = (limit - used).clamp(0, limit);

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: SafeArea(
            bottom: false,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildTopBar(),
                const SizedBox(height: 8),
                _buildMainCard(used, remaining, pct, limit),
                const SizedBox(height: 14),
                WeekChart(
                  weekData: _weekData,
                  onTap: () => setState(() => _tab = 2),
                ),
                const SizedBox(height: 14),
                if (_apps.isNotEmpty) _buildTopApps(),
                const SizedBox(height: 14),
                _buildQuoteBar(),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(
        children: [
          const Text(
            'وقتي',
            style: TextStyle(
              fontFamily: 'Tajawal',
              fontSize: 24,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(Icons.settings_rounded,
                  color: Colors.white.withOpacity(0.6), size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMainCard(int used, int remaining, double pct, int limit) {
    final Color statusColor = pct >= 1.0
        ? const Color(0xFFE53935)
        : pct >= 0.85
            ? const Color(0xFFFFB300)
            : _kOrange;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            statusColor.withOpacity(0.2),
            const Color(0xFF0A0A0A),
          ],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: statusColor.withOpacity(0.3), width: 1.5),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _formatMinutes(used),
                    style: TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 36,
                      fontWeight: FontWeight.w900,
                      color: statusColor,
                    ),
                  ),
                  Text(
                    'استخدمت اليوم',
                    style: TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 13,
                      color: Colors.white.withOpacity(0.5),
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    _formatMinutes(remaining),
                    style: const TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 28,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    'متبقي',
                    style: TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 13,
                      color: Colors.white.withOpacity(0.5),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: pct,
              backgroundColor: Colors.white.withOpacity(0.1),
              valueColor: AlwaysStoppedAnimation<Color>(statusColor),
              minHeight: 8,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'الحد اليومي: ${_formatMinutes(limit)}',
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 11,
                  color: Colors.white.withOpacity(0.35),
                ),
              ),
              Text(
                '${(pct * 100).round()}%',
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: statusColor,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTopApps() {
    final top = _apps.take(3).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            'الأكثر استخداماً',
            style: TextStyle(
              fontFamily: 'Tajawal',
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Colors.white.withOpacity(0.7),
            ),
          ),
        ),
        const SizedBox(height: 10),
        ...top.map((app) => _AppTile(app: app, formatMinutes: _formatMinutes)),
      ],
    );
  }

  Widget _buildQuoteBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          const Text('💡', style: TextStyle(fontSize: 18)),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'وقتك أثمن من أن تضيعه — استثمره بحكمة',
              style: TextStyle(
                fontFamily: 'Tajawal',
                fontSize: 13,
                color: Colors.white.withOpacity(0.6),
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AppTile extends StatelessWidget {
  final AppModel app;
  final String Function(int) formatMinutes;

  const _AppTile({required this.app, required this.formatMinutes});

  @override
  Widget build(BuildContext context) {
    final pct = app.limitMinutes > 0
        ? (app.usedMinutes / app.limitMinutes).clamp(0.0, 1.0)
        : 0.0;
    final color = pct >= 1.0
        ? const Color(0xFFE53935)
        : pct >= 0.8
            ? const Color(0xFFFFB300)
            : const Color(0xFF4CAF50);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF141414),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                app.name.isNotEmpty ? app.name[0] : '?',
                style: const TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  app.name,
                  style: const TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                LinearProgressIndicator(
                  value: pct,
                  backgroundColor: Colors.white.withOpacity(0.1),
                  valueColor: AlwaysStoppedAnimation<Color>(color),
                  minHeight: 4,
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            formatMinutes(app.usedMinutes),
            style: TextStyle(
              fontFamily: 'Tajawal',
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
