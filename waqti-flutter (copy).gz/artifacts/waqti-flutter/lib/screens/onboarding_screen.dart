import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/usage_service.dart';
import 'home_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  bool _loading = false;

  static const _orange = Color(0xFFFF6B1A);

  final _permissions = [
    {
      'icon': Icons.bar_chart_rounded,
      'title': 'إحصائيات الاستخدام',
      'desc': 'لقراءة وقت استخدام التطبيقات',
    },
    {
      'icon': Icons.notifications_rounded,
      'title': 'الإشعارات',
      'desc': 'لإرسال تنبيهات عند اقتراب النهاية',
    },
    {
      'icon': Icons.layers_rounded,
      'title': 'الظهور فوق التطبيقات',
      'desc': 'لعرض إشعارات الانتهاء',
    },
  ];

  Future<void> _requestAndContinue() async {
    setState(() => _loading = true);

    final hasUsage = await UsageService.hasUsagePermission();
    if (!hasUsage) await UsageService.openUsageSettings();

    final hasOverlay = await UsageService.hasOverlayPermission();
    if (!hasOverlay) await UsageService.openOverlaySettings();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarding_done', true);

    if (!mounted) return;
    setState(() => _loading = false);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              const SizedBox(height: 48),
              Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: _orange.withOpacity(0.4),
                      blurRadius: 30,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Center(
                  child: Text('~', style: TextStyle(fontSize: 36, color: _orange)),
                ),
              ),
              const SizedBox(height: 28),
              const Text(
                'مرحباً في وقتي',
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'راقب استخدامك الرقمي وحافظ على التوازن\nالصحي بشكل ذكي وجميل',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 15,
                  color: Colors.white.withOpacity(0.55),
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 36),
              Text(
                'يحتاج التطبيق للأذونات التالية',
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 13,
                  color: Colors.white.withOpacity(0.4),
                ),
              ),
              const SizedBox(height: 16),
              ..._permissions.map((p) => _PermissionTile(
                    icon: p['icon'] as IconData,
                    title: p['title'] as String,
                    desc: p['desc'] as String,
                  )),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _loading ? null : _requestAndContinue,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _orange,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: _loading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                        )
                      : const Text(
                          'ابدأ',
                          style: TextStyle(
                            fontFamily: 'Tajawal',
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}

class _PermissionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String desc;

  const _PermissionTile({required this.icon, required this.title, required this.desc});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: const Color(0xFFFF6B1A).withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: const Color(0xFFFF6B1A), size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  desc,
                  style: TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 12,
                    color: Colors.white.withOpacity(0.45),
                  ),
                ),
              ],
            ),
          ),
          Icon(Icons.circle_outlined, color: Colors.white.withOpacity(0.3), size: 20),
        ],
      ),
    );
  }
}
