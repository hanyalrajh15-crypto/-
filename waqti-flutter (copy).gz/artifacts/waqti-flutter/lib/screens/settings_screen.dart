import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import '../services/usage_service.dart';

const _kOrange = Color(0xFFFF6B1A);

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late int _dailyLimit;
  late int _warningMin;
  bool _hasUsage = false;
  bool _hasOverlay = false;
  bool _hasAccessibility = false;

  @override
  void initState() {
    super.initState();
    _dailyLimit = StorageService.getDailyLimit();
    _warningMin = StorageService.getWarningMinutes();
    _checkPermissions();
  }

  Future<void> _checkPermissions() async {
    try {
      final u = await UsageService.hasUsagePermission();
      final o = await UsageService.hasOverlayPermission();
      final a = await UsageService.hasAccessibilityPermission();
      setState(() {
        _hasUsage = u;
        _hasOverlay = o;
        _hasAccessibility = a;
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        title: const Text(
          'الإعدادات',
          style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.w800),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_forward_ios_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _SectionTitle('الحدود'),
          _SettingCard(
            title: 'الحد اليومي الكلي',
            subtitle: '${_dailyLimit} دقيقة (${_dailyLimit ~/ 60} ساعة)',
            icon: Icons.timer_rounded,
            child: Column(
              children: [
                Text(
                  '$_dailyLimit د',
                  style: const TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: _kOrange,
                  ),
                ),
                Slider(
                  value: _dailyLimit.toDouble(),
                  min: 30,
                  max: 720,
                  divisions: 23,
                  activeColor: _kOrange,
                  label: '$_dailyLimit د',
                  onChanged: (v) async {
                    setState(() => _dailyLimit = v.round());
                    await StorageService.setDailyLimit(v.round());
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          _SettingCard(
            title: 'وقت التحذير',
            subtitle: 'تنبيه قبل $_warningMin دقيقة من انتهاء الوقت',
            icon: Icons.notifications_active_rounded,
            child: Column(
              children: [
                Text(
                  '$_warningMin د',
                  style: const TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFFFFB300),
                  ),
                ),
                Slider(
                  value: _warningMin.toDouble(),
                  min: 1,
                  max: 30,
                  divisions: 29,
                  activeColor: const Color(0xFFFFB300),
                  label: '$_warningMin د',
                  onChanged: (v) async {
                    setState(() => _warningMin = v.round());
                    await StorageService.setWarningMinutes(v.round());
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _SectionTitle('الأذونات'),
          _PermissionTile(
            icon: Icons.bar_chart_rounded,
            title: 'إحصائيات الاستخدام',
            granted: _hasUsage,
            onTap: () async {
              await UsageService.openUsageSettings();
              await _checkPermissions();
            },
          ),
          _PermissionTile(
            icon: Icons.layers_rounded,
            title: 'الظهور فوق التطبيقات',
            granted: _hasOverlay,
            onTap: () async {
              await UsageService.openOverlaySettings();
              await _checkPermissions();
            },
          ),
          _PermissionTile(
            icon: Icons.accessibility_new_rounded,
            title: 'خدمة إمكانية الوصول',
            granted: _hasAccessibility,
            onTap: () async {
              await UsageService.openAccessibilitySettings();
              await _checkPermissions();
            },
          ),
          const SizedBox(height: 20),
          _SectionTitle('الخدمة'),
          _SettingAction(
            icon: Icons.play_circle_rounded,
            title: 'تشغيل خدمة المراقبة',
            onTap: () async {
              try {
                await UsageService.startMonitorService();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم تشغيل الخدمة',
                        style: TextStyle(fontFamily: 'Tajawal')),
                    backgroundColor: _kOrange,
                  ),
                );
              } catch (_) {}
            },
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;

  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, top: 4),
      child: Text(
        title,
        style: TextStyle(
          fontFamily: 'Tajawal',
          fontSize: 13,
          fontWeight: FontWeight.w700,
          color: Colors.white.withOpacity(0.4),
          letterSpacing: 1,
        ),
      ),
    );
  }
}

class _SettingCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget child;

  const _SettingCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF141414),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: _kOrange, size: 20),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontFamily: 'Tajawal',
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Colors.white)),
                  Text(subtitle,
                      style: TextStyle(
                          fontFamily: 'Tajawal',
                          fontSize: 11,
                          color: Colors.white.withOpacity(0.4))),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _PermissionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool granted;
  final VoidCallback onTap;

  const _PermissionTile({
    required this.icon,
    required this.title,
    required this.granted,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: granted ? null : onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF141414),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: granted
                ? const Color(0xFF4CAF50).withOpacity(0.4)
                : Colors.white.withOpacity(0.06),
          ),
        ),
        child: Row(
          children: [
            Icon(icon,
                color: granted ? const Color(0xFF4CAF50) : Colors.white54,
                size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
            if (granted)
              const Icon(Icons.check_circle_rounded,
                  color: Color(0xFF4CAF50), size: 20)
            else
              const Icon(Icons.arrow_forward_ios_rounded,
                  color: Colors.white24, size: 16),
          ],
        ),
      ),
    );
  }
}

class _SettingAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _SettingAction({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _kOrange.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _kOrange.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: _kOrange, size: 22),
            const SizedBox(width: 12),
            Text(
              title,
              style: const TextStyle(
                fontFamily: 'Tajawal',
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: _kOrange,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
