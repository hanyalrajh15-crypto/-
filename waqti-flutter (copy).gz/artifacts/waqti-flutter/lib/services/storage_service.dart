import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static late SharedPreferences _p;

  static Future<void> init() async {
    _p = await SharedPreferences.getInstance();
  }

  static Future<void> setAppLimit(String pkg, int minutes) async {
    await _p.setInt('limit_$pkg', minutes);
    final list = _p.getStringList('monitored_apps') ?? [];
    if (!list.contains(pkg)) {
      list.add(pkg);
      await _p.setStringList('monitored_apps', list);
    }
  }

  static int getAppLimit(String pkg) => _p.getInt('limit_$pkg') ?? 0;

  static Future<void> setDailyLimit(int minutes) async =>
      await _p.setInt('global_daily_limit', minutes);

  static int getDailyLimit() => _p.getInt('global_daily_limit') ?? 360;

  static Future<void> setWarningMinutes(int min) async =>
      await _p.setInt('warning_min', min);

  static int getWarningMinutes() => _p.getInt('warning_min') ?? 10;

  static Future<void> setDayLimit(String date, int minutes) async =>
      await _p.setInt('day_limit_$date', minutes);

  static int getDayLimit(String date) => _p.getInt('day_limit_$date') ?? 0;

  static Future<void> saveAlarm(String pkg, String alarmData) async {
    final expiry =
        DateTime.now().add(const Duration(days: 30)).toIso8601String();
    await _p.setString('alarm_${pkg}_data', alarmData);
    await _p.setString('alarm_${pkg}_expiry', expiry);
  }

  static String? getAlarm(String pkg) {
    final expiry = _p.getString('alarm_${pkg}_expiry');
    if (expiry == null) return null;
    if (DateTime.parse(expiry).isBefore(DateTime.now())) {
      _p.remove('alarm_${pkg}_data');
      _p.remove('alarm_${pkg}_expiry');
      return null;
    }
    return _p.getString('alarm_${pkg}_data');
  }
}
