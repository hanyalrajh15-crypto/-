import 'package:flutter/services.dart';

class UsageService {
  static const _ch = MethodChannel('com.waqti.app/usage');

  static Future<Map<String, int>> getTodayUsage() async {
    final r = await _ch.invokeMethod('getTodayUsage');
    return Map<String, int>.from(
        r.map((k, v) => MapEntry(k.toString(), (v as num).toInt())));
  }

  static Future<List<Map>> getInstalledApps() async {
    final r = await _ch.invokeMethod('getInstalledApps');
    return List<Map>.from(r);
  }

  static Future<bool> hasUsagePermission() async =>
      await _ch.invokeMethod('hasUsageStatsPermission');

  static Future<void> openUsageSettings() async =>
      await _ch.invokeMethod('openUsageStatsSettings');

  static Future<bool> hasOverlayPermission() async =>
      await _ch.invokeMethod('hasOverlayPermission');

  static Future<void> openOverlaySettings() async =>
      await _ch.invokeMethod('openOverlaySettings');

  static Future<bool> hasAccessibilityPermission() async =>
      await _ch.invokeMethod('hasAccessibilityPermission');

  static Future<void> openAccessibilitySettings() async =>
      await _ch.invokeMethod('openAccessibilitySettings');

  static Future<void> startMonitorService() async =>
      await _ch.invokeMethod('startMonitorService');
}
