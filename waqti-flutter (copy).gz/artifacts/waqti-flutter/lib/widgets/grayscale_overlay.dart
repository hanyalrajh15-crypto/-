import 'package:flutter/material.dart';

class GrayscaleOverlay extends StatelessWidget {
  final Widget child;
  final bool enabled;

  const GrayscaleOverlay(
      {super.key, required this.child, this.enabled = false});

  @override
  Widget build(BuildContext context) {
    if (!enabled) return child;
    return ColorFiltered(
      colorFilter: const ColorFilter.matrix([
        0.2126, 0.7152, 0.0722, 0, 0,
        0.2126, 0.7152, 0.0722, 0, 0,
        0.2126, 0.7152, 0.0722, 0, 0,
        0,      0,      0,      1, 0,
      ]),
      child: child,
    );
  }
}
