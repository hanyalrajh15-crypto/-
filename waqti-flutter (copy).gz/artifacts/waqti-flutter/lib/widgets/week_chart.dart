import 'package:flutter/material.dart';
import '../models/app_model.dart';

const _kOrange = Color(0xFFFF6B1A);
const _kGreen = Color(0xFF4CAF50);
const _kYellow = Color(0xFFFFB300);
const _kRed = Color(0xFFE53935);

const _dayNames = ['أح', 'إث', 'ثل', 'أر', 'خم', 'جم', 'سب'];

class WeekChart extends StatelessWidget {
  final List<DayData> weekData;
  final VoidCallback? onTap;

  const WeekChart({super.key, required this.weekData, this.onTap});

  Color _barColor(DayData d) {
    if (d.status == 'none') return Colors.white.withOpacity(0.2);
    if (d.status == 'good') return _kGreen;
    if (d.status == 'warn') return _kYellow;
    return _kRed;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _kOrange.withOpacity(0.07),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _kOrange.withOpacity(0.25), width: 1.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'الأسبوع الحالي',
                  style: TextStyle(
                    fontFamily: 'Tajawal',
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFFFFAA7A),
                  ),
                ),
                const Icon(Icons.arrow_back, color: _kOrange, size: 16),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 100,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: weekData.asMap().entries.map((e) {
                  final i = e.key;
                  final day = e.value;
                  final isToday = i == weekData.length - 1;
                  final pct = day.limitMinutes > 0
                      ? (day.usedMinutes / day.limitMinutes).clamp(0.0, 1.0)
                      : 0.0;
                  final barColor = _barColor(day);

                  return Expanded(
                    child: Column(
                      children: [
                        Expanded(
                          child: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.05),
                              borderRadius: BorderRadius.circular(8),
                              border: isToday
                                  ? Border.all(color: _kOrange, width: 2)
                                  : Border.all(color: Colors.white.withOpacity(0.06)),
                            ),
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: AnimatedFractionallySizedBox(
                                duration: Duration(milliseconds: 600 + i * 80),
                                curve: Curves.elasticOut,
                                heightFactor: pct,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: barColor,
                                    borderRadius: BorderRadius.circular(6),
                                    boxShadow: pct > 0
                                        ? [BoxShadow(color: barColor.withOpacity(0.6), blurRadius: 6)]
                                        : null,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          width: 5,
                          height: 5,
                          decoration: BoxDecoration(
                            color: barColor,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _dayNames[i % 7],
                          style: TextStyle(
                            fontFamily: 'Tajawal',
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            color: isToday ? _kOrange : Colors.white.withOpacity(0.4),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
